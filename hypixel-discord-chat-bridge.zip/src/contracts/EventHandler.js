class EventHandler {
  registerEvents(bot) {
    throw new Error('Event Handler registerEvents is not implemented yet!')
  }
}

module.exports = EventHandler
